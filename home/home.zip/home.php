<?php
require_once('../common.php');
require_once('head.php');
?>
<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
   <center> <h2 class="font-bold">这里是班级中心哦！</h2></center>
 <div class="row">
            <div class="col-sm-4">
                <div class="widget-head-color-box navy-bg p-lg text-center">
                    
                    <img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$userrow['qq']?>&s=160" class="img-circle circle-border m-b-md" alt="profile">
                       <div>
                        <h2 class="font-bold no-margins"><?=$userrow['xm']?></h2> 
                    </div>
                    <div>
                        <span><?=$userrow['gxqm']?></span> 
                    </div>

                </div>
                <div class="widget-text-box">
                    <p>用户名:<?=$userrow['user']?></p>
                    <p>权限:
                                    <?php
                                   if ($userrow['active']==9) {
                                   echo "ADMIN-管理员";
                                   }elseif ($userrow['active']==8) {
                                   echo "ADMIN-副管理";
                                   }elseif ($userrow['active']==7) {
                                    echo "老师";
                                    }elseif ($userrow['active']==6) {
                                    echo "班长";
                                   }else{
                                    echo "普通学生";
                                   }
                                  ?></p>
                    <p>Phone:<?=$userrow['phone']?></p>
                </div>
                 
            </div>
            <div class="col-sm-8">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>班级公告 <small class="m-l-sm">看看班级都有些什么新鲜事呢！</small></h5>
                    </div>
                    <div class="ibox-content">
                    <?=C('bjgg')?>
                    </div>
                </div>
                </div>
                 <div class="col-sm-4">
                 <div class="widget lazur-bg p-lg">
                    <div class="m-b-md">
                        <center><i class="glyphicon glyphicon-tag fa-3x"></i>
                        <h3 class="font-bold no-margins">
                                当前日期
                            </h3>
                            
                            <hr>
                        <h2><?php echo date('m-d') ?></h2></center>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                 <div class="widget blue-bg p-lg">
                    <div class="m-b-md">
                        <center><i class="glyphicon glyphicon-time fa-3x"></i>
                        <h3 class="font-bold no-margins">
                               当前时间
                            </h3>
                            
                            <hr>
                        <center> <h2><?php echo date('H:i:s') ?></h2></center>
                    </div>
                </div>
            </div>

            </div>
        </div>

<?php
require_once('foot.php');
?>

